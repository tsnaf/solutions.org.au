
$(document).ready(function(){var a=$("#chatbutton-wa");a.floatingWhatsApp({phone:a.attr("data-phone"),popupMessage:a.attr("data-popupmessage"),headerName:a.attr("data-headername"),headerTitle:a.attr("data-headertitle"),message:a.attr("data-message"),placeholder:a.attr("data-placeholder"),showPopup:a.attr("data-showpopup"),position:a.attr("data-position"),headerColor:a.attr("data-headerColor"),autoOpenTimeout:a.attr("data-autoOpenTimeout"),size:a.attr("data-size"),buttonImage:a.attr("data-image"),
backgroundColor:a.attr("data-backgroundColor")})});
